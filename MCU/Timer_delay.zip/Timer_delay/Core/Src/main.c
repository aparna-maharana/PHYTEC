#include "main.h"
void timer_delay()
{
	RCC->APB1ENR |=0X1;
	TIM2->PSC = 1600-1;
	TIM2->ARR = 1000-1;
	TIM2->CNT = 0;
	TIM2->CR1 = 1;
}

int main()
{
	/* Enable GPIO */
	RCC->AHB1ENR |=0X3;
	GPIOA->MODER |=0X400;
	timer_delay();

	while(1)
	{
		while(!(TIM2->SR & 1));
		GPIOA->ODR ^=0X20;
		TIM2->SR =0;
	}
}
