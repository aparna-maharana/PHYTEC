/*
 * hello.h
 *
 *  Created on: Apr 25, 2023
 *      Author: PHY202302EF28
 */

#ifndef HELLO_H_
#define HELLO_H_

void delay(int T);
void UART2_Init(void);
int __io_putchar(unsigned char ch);
void Usart2_Transmit(unsigned char ch);

#endif
